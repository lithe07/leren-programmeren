from rename_me import even_oneven

voorbeeld = 60
test = even_oneven(voorbeeld)
print(f"is {voorbeeld} een even getal? {test}")