from rename_me import reverse_zin


voorbeeld = 'hallo eri fik ya osama '
test = reverse_zin(voorbeeld)
print(test)