from rename_me import getal_keren


voorbeeld = 9
test  = getal_keren(voorbeeld)
print(test)