from rename_me import optellen_met_komma


voorbeeld = 'gkudigsfhj'
test = optellen_met_komma(voorbeeld)
print(test)