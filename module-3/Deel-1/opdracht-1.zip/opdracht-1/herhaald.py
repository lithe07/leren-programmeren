from rename_me import herhaald_optellen


voorbeeld = 'werttyyuii'
test = herhaald_optellen(voorbeeld)
print(test)